import React, { useState } from 'react';
import { ArrowLeft, Mail, MessageSquare, User, Send } from 'lucide-react';

interface ContactUsProps {
  setCurrentPage: (page: string) => void;
}

function ContactUs({ setCurrentPage }: ContactUsProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');
  const [submitStatus, setSubmitStatus] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitStatus('success');
      setSubmitMessage('Thank you for your message! We will get back to you soon.');
      setFormData({
        name: '',
        email: '',
        message: ''
      });
    }, 1500);
  };

  return (
    <main className="container py-8">
      <div className="card max-w-4xl mx-auto p-6 mb-8">
        <button 
          onClick={() => setCurrentPage('home')}
          className="flex items-center text-secondary mb-6"
          style={{ textDecoration: 'none' }}
        >
          <ArrowLeft size={16} className="mr-1" />
          <span>Back to Home</span>
        </button>
        
        <h1 className="text-3xl font-bold mb-6">Contact Us</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Get in Touch</h2>
            <p className="mb-6">
              Have questions, suggestions, or feedback about YouTube-Thumbnail-Save.com? We'd love to hear from you! Fill out the form, and we'll get back to you as soon as possible.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <Mail className="text-primary mr-3 mt-1" size={20} />
                <div>
                  <h3 className="font-medium">Email Us</h3>
                  <p className="text-light">contact@youtube-thumbnail-save.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <MessageSquare className="text-primary mr-3 mt-1" size={20} />
                <div>
                  <h3 className="font- medium">Response Time</h3>
                  <p className="text-light">We typically respond within 1-2 business days.</p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <h2 className="text-xl font-semibold mb-4">Common Inquiries</h2>
              <div className="space-y-3">
                <details className="bg-light p-3 rounded-md">
                  <summary className="font-medium cursor-pointer">Is this service completely free?</summary>
                  <p className="mt-2">Yes, YouTube-Thumbnail-Save.com is completely free to use with no hidden charges or premium features.</p>
                </details>
                
                <details className="bg-light p-3 rounded-md">
                  <summary className="font-medium cursor-pointer">Do you store the thumbnails I download?</summary>
                  <p className="mt-2">No, we don't store any thumbnails on our servers. The tool simply helps you access publicly available thumbnail images directly from YouTube.</p>
                </details>
                
                <details className="bg-light p-3 rounded-md">
                  <summary className="font-medium cursor-pointer">Can I use the thumbnails commercially?</summary>
                  <p className="mt-2">Thumbnails are subject to YouTube's copyright policies. We recommend checking YouTube's terms of service regarding the use of thumbnails for commercial purposes.</p>
                </details>
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold mb-4">Send Us a Message</h2>
            
            {submitStatus === 'success' ? (
              <div className="bg-success-light">
                {submitMessage}
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="label">Your Name</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="text-light" size={18} />
                    </div>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="input input-with-icon"
                      placeholder="John Doe"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="email" className="label">Your Email</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="text-light" size={18} />
                    </div>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="input input-with-icon"
                      placeholder="john@example.com"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="message" className="label">Your Message</label>
                  <div className="relative">
                    <div className="absolute top-3 left-3 pointer-events-none">
                      <MessageSquare className="text-light" size={18} />
                    </div>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={5}
                      className="textarea textarea-with-icon"
                      placeholder="How can we help you?"
                      required
                    ></textarea>
                  </div>
                </div>
                
                <button
                  type="submit"
                  className="btn btn-primary btn-block"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center">
                      <svg className="spinner mr-2" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Sending...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center">
                      <Send className="mr-2" size={18} />
                      Send Message
                    </span>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

export default ContactUs;