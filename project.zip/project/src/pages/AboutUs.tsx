import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface AboutUsProps {
  setCurrentPage: (page: string) => void;
}

function AboutUs({ setCurrentPage }: AboutUsProps) {
  return (
    <main className="container py-8">
      <div className="card max-w-4xl mx-auto p-6 mb-8">
        <button 
          onClick={() => setCurrentPage('home')}
          className="flex items-center text-secondary mb-6"
          style={{ textDecoration: 'none' }}
        >
          <ArrowLeft size={16} className="mr-1" />
          <span>Back to Home</span>
        </button>
        
        <h1 className="text-3xl font-bold mb-6">About YouTube-Thumbnail-Save.com</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-xl font-semibold mt-6 mb-3">Our Mission</h2>
          <p>
            At YouTube-Thumbnail-Save.com, our mission is simple: to provide content creators, marketers, and YouTube enthusiasts with the easiest and most reliable way to download high-quality YouTube thumbnails.
          </p>
          <p className="mt-3">
            We believe that access to thumbnails should be straightforward and hassle-free. Whether you're a professional content creator looking to analyze successful thumbnails, a marketer creating promotional materials, or simply someone who wants to save a great thumbnail, our tool is designed with you in mind.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-3">Who We Are</h2>
          <p>
            YouTube-Thumbnail-Save.com was created by a small team of content creators and web developers who were frustrated with the complicated and ad-filled thumbnail downloaders available online. We wanted a clean, simple, and effective solution – so we built one ourselves.
          </p>
          <p className="mt-3">
            Our team has years of experience in content creation, digital marketing, and web development. We understand the challenges that creators face and have designed our tool to address real needs in the YouTube ecosystem.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-3">What Sets Us Apart</h2>
          <ul className="list-disc space-y-2">
            <li><strong>Simplicity:</strong> No complicated interfaces or confusing options – just paste a URL and get your thumbnails.</li>
            <li><strong>Comprehensive Quality Options:</strong> We provide access to all available thumbnail qualities, from the smallest default size to the highest resolution maxres version.</li>
            <li><strong>No Registration Required:</strong> Use our tool instantly without creating accounts or sharing personal information.</li>
            <li><strong>Ad-Free Experience:</strong> We believe in a clean, distraction-free user experience.</li>
            <li><strong>Mobile-Friendly Design:</strong> Our tool works perfectly on smartphones and tablets, so you can download thumbnails on any device.</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-3">Our Values</h2>
          <p>
            At YouTube-Thumbnail-Save.com, we're guided by a few core principles:
          </p>
          <ul className="list-disc space-y-2">
            <li><strong>Respect for Creators:</strong> We understand that thumbnails are an important part of a creator's work, and our tool is designed to support the creative community.</li>
            <li><strong>Commitment to Simplicity:</strong> We believe that the best tools are those that do one thing exceptionally well.</li>
            <li><strong>User Privacy:</strong> We don't track individual usage or collect unnecessary data.</li>
            <li><strong>Continuous Improvement:</strong> We're always looking for ways to make our tool better and more useful for our users.</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-3">Looking Forward</h2>
          <p>
            As YouTube continues to evolve, so will YouTube-Thumbnail-Save.com. We're committed to maintaining and improving our tool to ensure it remains the best way to download YouTube thumbnails.
          </p>
          <p className="mt-3">
            We welcome feedback from our users and are always open to suggestions for new features or improvements. If you have ideas about how we can make YouTube-Thumbnail-Save.com better, please don't hesitate to reach out through our Contact page.
          </p>
          
          <p className="mt-8">
            Thank you for choosing YouTube-Thumbnail-Save.com for your thumbnail downloading needs. We're proud to be part of your creative process!
          </p>
        </div>
      </div>
    </main>
  );
}

export default AboutUs;