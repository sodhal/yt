import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface PrivacyPolicyProps {
  setCurrentPage: (page: string) => void;
}

function PrivacyPolicy({ setCurrentPage }: PrivacyPolicyProps) {
  return (
    <main className="container py-8">
      <div className="card max-w-4xl mx-auto p-6 mb-8">
        <button 
          onClick={() => setCurrentPage('home')}
          className="flex items-center text-secondary mb-6"
          style={{ textDecoration: 'none' }}
        >
          <ArrowLeft size={16} className="mr-1" />
          <span>Back to Home</span>
        </button>
        
        <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
        <p className="text-light mb-6">Last Updated: June 15, 2025</p>
        
        <div className="prose max-w-none">
          <p>
            At YouTube-Thumbnail-Save.com, we take your privacy seriously. This Privacy Policy explains how we collect, use, and protect your information when you use our website.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">Information We Collect</h2>
          <p>
            <strong>YouTube URLs:</strong> When you use our thumbnail downloader, we temporarily process the YouTube URL you provide to extract the video ID and generate thumbnail links. We do not store these URLs after processing.
          </p>
          <p className="mt-3">
            <strong>Usage Data:</strong> We collect anonymous usage data such as page views, tool usage, and general traffic patterns. This information helps us improve our service and understand how users interact with our website.
          </p>
          <p className="mt-3">
            <strong>Contact Information:</strong> If you choose to contact us through our contact form, we collect the information you provide, such as your name, email address, and message content.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">How We Use Your Information</h2>
          <p>
            We use the information we collect to:
          </p>
          <ul className="list-disc space-y-1">
            <li>Provide and maintain our thumbnail downloading service</li>
            <li>Improve and optimize our website and user experience</li>
            <li>Respond to your inquiries and support requests</li>
            <li>Monitor and analyze usage patterns and trends</li>
            <li>Protect our website from abuse and unauthorized access</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">Cookies and Tracking Technologies</h2>
          <p>
            YouTube-Thumbnail-Save.com uses cookies and similar tracking technologies to enhance your browsing experience and collect usage data. These technologies help us understand how visitors use our website and allow us to improve our service.
          </p>
          <p className="mt-3">
            You can control cookie settings through your browser preferences. However, disabling cookies may affect the functionality of our website.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">Data Security</h2>
          <p>
            We implement appropriate security measures to protect your information from unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">Third-Party Services</h2>
          <p>
            YouTube-Thumbnail-Save.com may use third-party services for analytics, hosting, and other operational purposes. These services may collect information sent by your browser as part of their standard operations. Their use of this information is governed by their respective privacy policies.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">YouTube Content</h2>
          <p>
            Our service helps you access publicly available thumbnail images from YouTube videos. We do not host or store these thumbnails on our servers. The use of YouTube content through our service is subject to YouTube's Terms of Service and Privacy Policy.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">Children's Privacy</h2>
          <p>
            YouTube-Thumbnail-Save.com is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13. If you believe we have collected information from a child under 13, please contact us immediately.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">Changes to This Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. We encourage you to review this Privacy Policy periodically for any changes.
          </p>
          
          <h2 className="text-xl font-semibold mt-6 mb-3">Contact Us</h2>
          <p>
            If you have any questions or concerns about this Privacy Policy or our data practices, please contact us through our Contact page or by email at privacy@youtube-thumbnail-save.com.
          </p>
          
          <p className="mt-8">
            By using YouTube-Thumbnail-Save.com, you agree to the collection and use of information in accordance with this Privacy Policy.
          </p>
        </div>
      </div>
    </main>
  );
}

export default PrivacyPolicy;